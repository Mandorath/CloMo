# filebeat formula

0.0.1 (2015-12-10)
* Initial version
