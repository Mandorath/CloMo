logstash formula
================

0.0.3 (2014-08-02)
  - Fixed mode of 01-inputs.conf

0.0.2 (2014-08-02)
 - Updated README information

0.0.1 (2014-08-19)
 - Initial commit
